package com.example.InsuranceSystem_Web.src.entity.customer.enums;

public enum ShipType {
    General,
    Container;
}