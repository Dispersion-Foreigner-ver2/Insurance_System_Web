package com.example.InsuranceSystem_Web.src.dao.staff;

import com.example.InsuranceSystem_Web.src.entity.staff.Staff;
import org.springframework.data.jpa.repository.JpaRepository;


public interface StaffDao extends JpaRepository<Staff, Long> {

}
