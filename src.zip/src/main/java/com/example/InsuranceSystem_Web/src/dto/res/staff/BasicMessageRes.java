package com.example.InsuranceSystem_Web.src.dto.res.staff;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
@AllArgsConstructor
public class BasicMessageRes {
    String message;
}
