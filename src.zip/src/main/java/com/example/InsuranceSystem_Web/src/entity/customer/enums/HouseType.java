package com.example.InsuranceSystem_Web.src.entity.customer.enums;

public enum HouseType {
    apartment,
    housing,
    officetels
}