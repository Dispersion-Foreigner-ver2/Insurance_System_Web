package com.example.InsuranceSystem_Web.src.dto.res.insurance;

import lombok.*;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeleteInsuranceRes {
    private String message;
}
