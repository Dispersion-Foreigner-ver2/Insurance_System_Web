package com.example.InsuranceSystem_Web.src.dto.res.compensation;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
@AllArgsConstructor
public class PostCarDisclaimerRes {
    private String message;
}
