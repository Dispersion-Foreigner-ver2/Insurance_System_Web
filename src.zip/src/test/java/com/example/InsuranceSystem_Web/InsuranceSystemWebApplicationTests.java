package com.example.InsuranceSystem_Web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsuranceSystemWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
